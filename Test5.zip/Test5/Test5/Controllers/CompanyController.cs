﻿using Microsoft.AspNetCore.Mvc;
using Test5.Entities;

namespace Test5.Controllers
{
    public class CompanyController : Controller
    {
        private readonly SchoolContext schoolContext;
        public CompanyController()
        {
            schoolContext = new SchoolContext();
        }
        public IActionResult Index() //To display All companies
        {
            var companies = schoolContext.Companies.ToList();
            return View(companies);
        }
        [HttpGet]
        public IActionResult Create(int id)
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Company c)
        {
            schoolContext.Companies.Add(c);
            schoolContext.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
