﻿using Microsoft.AspNetCore.Mvc;
using Test5.Entities;

namespace Test5.Controllers
{
    public class StudentController : Controller
    {
        private readonly SchoolContext schoolContext;
        public StudentController()
        {
            schoolContext = new SchoolContext();
        }
        public IActionResult Index()
        {
            var students = schoolContext.Students.ToList();
            return View(students);
        }
        //To Add Student
        [HttpGet]
        public IActionResult Create(int id)
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Student std)
        {
            schoolContext.Students.Add(std);
            schoolContext.SaveChanges();
            return RedirectToAction("Index");
        }

        //Get Student details by studentId 
        public IActionResult details(int id)
        {
            var student = schoolContext.Students.Single(q=>q.StudentId == id);
            return View(student);
        }
        //Update Student skill,qualification by  id
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var student = schoolContext.Students.Single(q => q.StudentId == id);
            return View(student);
        }
        [HttpPost]
        public IActionResult Edit(Student student)
        {
            schoolContext.Students.Update(student);
            schoolContext.SaveChanges();
            return RedirectToAction("Index");
        }

        //To delete student by id
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var student = schoolContext.Students.Single(q => q.StudentId == id);
            return View(student);
        }
        [HttpPost]
        public IActionResult Delete(Student student)
        {
            schoolContext.Students.Remove(student);
            schoolContext.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
