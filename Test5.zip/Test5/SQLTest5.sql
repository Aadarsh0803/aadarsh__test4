create database school
use school

create table Company
(CompanyId int,Name varchar(50),City varchar(50),Address varchar(50))

select * from Company
insert into Company(CompanyId,Name,City,Address)
values
(1,'Fint Solutions','Hyderabad','Dallas Centre'),
(2,'Accenture','Hyderabad','Gachiboli'),
(3,'Tata Consultancy','Mumbai','Maharastra'),
(4,'Microsoft','Delhi','Delhi'),
(5,'Infosis','Hyderabad','Telangana'),
(6,'Amazon','Pune','Maharastra')

create table Students
(StudentId int,Name varchar(40),Qualification varchar(40),Skill varchar(30))

select * from Students

insert into Students(StudentId,Name,Qualification,Skill)
values
(1,'Aadarsh','B.Tech','Python'),
(2,'Jashwanth','B.Tech','Java'),
(3,'Sudheer','MBA','HTML'),
(4,'Surendra','B.Tech','c#'),
(5,'Chaitanya','M.Tech','MVC'),
(6,'Sridhar','B.Tech','Java'),
(7,'Sai Teja','B.Tech','Python'),
(8,'Sri Vastav','B.Tech','Java'),
(9,'Sanjay','B.Tech','C'),
(10,'Rohith','B.Tech','OOPS')